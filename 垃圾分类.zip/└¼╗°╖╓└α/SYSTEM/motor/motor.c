//motor.c
#include "motor.h"
#include "shumaguan.h"
#include "usart.h"
#include "stringprotocol.h"
/*GPIO_motornum��GPIOx����ѡ������GPIO_direction����ѡ��������dir��0Ϊ��1Ϊ����kΪ90��ı���*/
// GPIO
#define speedx 12700
#define speedy 8500
#define motortime 2 
int a[4]={1,speedx,1,speedy};
int b[4]={0,speedx,1,speedy};
int c[4]={0,speedx,0,speedy};
int d[4]={1,speedx+200,0,speedy};
char flag=0;
extern char mode;
void MOTOR_Init()
{
  GPIO_InitTypeDef GPIO_InitStructure;
  RCC_APB2PeriphClockCmd(Motor_RCC,ENABLE);
	
	//Motor��ʼ��
	GPIO_InitStructure.GPIO_Pin = Motor1_STEP|Motor1_DIR|Motor2_STEP|Motor2_DIR;
	GPIO_InitStructure.GPIO_Mode=GPIO_Mode_Out_PP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(Motor_GPIO,&GPIO_InitStructure);	// ��ʼ��GPIOB
	GPIO_ResetBits(Motor_GPIO,Motor1_STEP);			//��ʼ��GPIOF_1����͵�ƽ
	GPIO_ResetBits(Motor_GPIO,Motor1_DIR);			//��ʼ��GPIOF_2����͵�ƽ
	GPIO_ResetBits(Motor_GPIO,Motor2_STEP);			//��ʼ��GPIOF_3����͵�ƽ
	GPIO_ResetBits(Motor_GPIO,Motor2_DIR);			//��ʼ��GPIOF_4����͵�ƽ
}

void motor(unsigned int motor1_dir, unsigned int motor1_step, unsigned int motor2_dir, unsigned int motor2_step)
{
    unsigned int i;	
		switch(motor1_dir)
		{
			case 0 : GPIO_SetBits(Motor_GPIO,Motor1_DIR); break; 
			case 1 : GPIO_ResetBits(Motor_GPIO,Motor1_DIR); break; 
			default : break; 
		}
		switch(motor2_dir)
		{
			case 0 : GPIO_SetBits(Motor_GPIO,Motor2_DIR); break; 
			case 1 : GPIO_ResetBits(Motor_GPIO,Motor2_DIR); break; 
			default : break; 
		}
		for(i = 0;i < motor1_step || i < motor2_step; i++)
		{
			if(i<motor1_step)
			{
				GPIO_SetBits(Motor_GPIO,Motor1_STEP);
				delay_us(156);									//����1.3ms
				GPIO_ResetBits(Motor_GPIO,Motor1_STEP);
				delay_us(156);
			}
			if(i<motor2_step)
			{
				GPIO_SetBits(Motor_GPIO,Motor2_STEP);
				delay_us(156);									//����1.3ms
				GPIO_ResetBits(Motor_GPIO,Motor2_STEP);
				delay_us(156);
			}
		}

    //delay_ms(2);					//��ʱһ��
}
void XYcontrol(void)
{
	USART_ITConfig(USART1, USART_IT_RXNE, DISABLE);//�رմ��ڽ����ж�
	//USART_ITConfig(USART3, USART_IT_RXNE, DISABLE);//�رմ��ڽ����ж�
	if(mode==1)
		motor(a[0],a[1],a[2],a[3]);
	if(mode==2)
		motor(b[0],b[1],b[2],b[3]);
	if(mode==3)
		motor(c[0],c[1],c[2],c[3]);
	if(mode==4)
		motor(d[0],d[1],d[2],d[3]);
	if(mode!=0)
	    flag=1;
	MyUSART_SendArr(Play6,6);
	returninit();
}

void returninit(void)
{
	unsigned char i;
	GPIO_SetBits(GPIOB,GPIO_Pin_5); //�ص�
	if(flag)
	{
	delay_ms(30);
	if(mode==1)
		motor(0,a[1],0,a[3]);
	if(mode==2)
		motor(1,b[1],0,b[3]);
	if(mode==3)
		motor(1,c[1],1,c[3]);
	if(mode==4)
		motor(0,d[1],1,d[3]);
	flag=0;
	for(i=0;i<USART_REC_LEN;i++)
	{
		USART_RX_BUF[i]=0;
		USART3_RX_BUF[i]=0;
	}                      //������ڽ��ջ���
	USART_ITConfig(USART1, USART_IT_RXNE, ENABLE);//�������ڽ����ж�
	USART_ITConfig(USART3, USART_IT_RXNE, ENABLE);//�������ڽ����ж�
    }
}

