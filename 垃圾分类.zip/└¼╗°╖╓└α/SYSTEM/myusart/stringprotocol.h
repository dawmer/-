#ifndef __stringprotocol_H
#define __STRINGPROTOCOL_H
void MyUSART_SendArr(u8 *str,uint8_t count);
void MyUSART_SendByte(u8 data);
extern u8 Play1[];
extern u8 Play2[];
extern u8 Play3[];
extern u8 Play4[];
extern u8 Play5[];
extern u8 Play6[];
extern u8 play[][6];
#endif
