#ifndef __shumaguan_H
#define __SHUMAGUAN_H
#include "sys.h"
#include "delay.h"
void HC595_GPIO_Configuration(void);
void HC595_Send_Data(unsigned char num, unsigned char show_bit);
void HC595_Send_Byte(unsigned char byte);
void display(unsigned int n);
extern unsigned int num[];
#endif
