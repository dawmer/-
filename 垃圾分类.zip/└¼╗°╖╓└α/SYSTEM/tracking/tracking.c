#include "tracking.h"

void tracking_GPIO_Config(void)
{
	GPIO_InitTypeDef GPIO_InitStructure;
	RCC_APB2PeriphClockCmd(tracking_GPIO_CLK,ENABLE);
	
	GPIO_InitStructure.GPIO_Pin=tracking_GPIO_PIN;
	GPIO_InitStructure.GPIO_Mode=GPIO_Mode_IN_FLOATING; 	
	GPIO_InitStructure.GPIO_Speed=GPIO_Speed_50MHz;
	GPIO_Init(tracking_GPIO_PORT, &GPIO_InitStructure);
}

uint8_t tracking_Scan(GPIO_TypeDef* GPIOx,uint16_t GPIO_Pin)
{
	if(GPIO_ReadInputDataBit(GPIOx,GPIO_Pin)==tracking_Low)
		return tracking_Low;
	else
		return tracking_High;
}
