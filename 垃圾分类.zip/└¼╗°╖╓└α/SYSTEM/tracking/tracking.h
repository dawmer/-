#ifndef __TRAKING_H
#define __TRAKING_H

#include "stm32f10x.h"

#define tracking_GPIO_CLK	   		RCC_APB2Periph_GPIOC
#define tracking_GPIO_PIN			GPIO_Pin_6
#define tracking_GPIO_PORT			GPIOC

#define tracking_High			1
#define tracking_Low			0

void tracking_GPIO_Config(void);
uint8_t tracking_Scan(GPIO_TypeDef* GPIOx,uint16_t GPIO_Pin);

#endif /* __TRAKING_H */
